package com.example.annie.dewatch.deWatchClient.Classes;

import java.util.Date;

/**
 * Created by krisley3094 on 11/03/18.
 */

public class ExerciseRecordRequestReadObject {

    private String uid;
    private String date;

    public ExerciseRecordRequestReadObject(String uid, String date) {
        this.uid = uid;
        this.date = date;
    }

}
