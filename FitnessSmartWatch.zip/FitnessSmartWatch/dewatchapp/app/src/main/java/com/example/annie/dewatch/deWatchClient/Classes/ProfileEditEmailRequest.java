package com.example.annie.dewatch.deWatchClient.Classes;

/**
 * Created by krisley3094 on 03/04/18.
 */

public class ProfileEditEmailRequest {
    private String uid;
    private String email;

    public ProfileEditEmailRequest(String uid, String email) {
        this.uid = uid;
        this.email = email;
    }
}
