package com.example.annie.dewatch.deWatchClient.Classes;

/**
 * Created by krisley3094 on 10/03/18.
 */

public class LoginRequestObject {

    private String email;
    private String password;

    public LoginRequestObject(String email, String password) {
        this.email = email;
        this.password = password;
    }
}
