package com.example.annie.dewatch;

/**
 * Created by krisley3094 on 08/03/18.
 */

public class Config {
    public static final String API_BASE_URL = "http://34.214.196.143:3000";
    public static final String APP_TAG = "DEWATCH";

}
