package com.example.annie.dewatch.deWatchClient.Classes;

/**
 * Created by krisley3094 on 10/03/18.
 */

public class AuthResponseObject {
    private String first_name;
    private String last_name;
    private String email;
    private String uid;
    private String gender;
    private int age;
    private int weight;
    private int code;

    public String getFirstName() { return first_name; }

    public String getLastName() { return last_name; }

    public String getEmail() { return email; }

    public String getUid() { return uid; }

    public String getGender() { return gender; }

    public int getAge() { return age; }

    public int getWeight() { return weight; }

    public int getCode() { return code; }

}
