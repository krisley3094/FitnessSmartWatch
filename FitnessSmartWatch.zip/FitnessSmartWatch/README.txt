cpen391_project2_linux: DE1 files -- run create_linux_system.sh to create an image on SD card
			NEEDS Altera SoC EDS to run
			files in cpen391_project2_linux/sw/hps/:
				/dev_irq_handler:  linux modules -- run make file 
				/DEWatch_C:        c project for watch
				/SpeechRecognizer: python project for speech detection

dewatchapp: Android app

server    : server files -- needs nodejs 
