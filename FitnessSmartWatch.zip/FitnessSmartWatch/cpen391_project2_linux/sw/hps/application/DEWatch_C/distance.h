/*
 * distance.h
 *
 *  Created on: Feb 13, 2018
 *      Author: krisley3094
 */

#ifndef DISTANCE_H_
#define DISTANCE_H_

void updateDistance (void);
void start_distance_tracking (void);
void stop_distance_tracking (void);

extern double currDistance;

#endif /* DISTANCE_H_ */
