/*
 * FirsScreen.h
 *
 *  Created on: Jan 31, 2018
 *      Author: Rouyeen
 */

#ifndef FIRSSCREEN_H_
#define FIRSSCREEN_H_

#include "../gui.h"

void draw_clock_screen(void);
void update_clock_screen(void);
void handle_touch_clock_screen (Screen *switch_to_screen);

#endif /* FIRSSCREEN_H_ */
