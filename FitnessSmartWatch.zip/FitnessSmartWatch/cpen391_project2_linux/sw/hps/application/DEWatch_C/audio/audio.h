/*
 * audio.h
 *
 *  Created on: Feb 9, 2018
 *      Author: Roy
 */

#ifndef AUDIO_H_
#define AUDIO_H_

void av_config_setup(void);

#endif /* AUDIO_H_ */
